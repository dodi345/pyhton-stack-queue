# Percobaan 1

stack = [1,2,3,4,5]
print(f"tumpukan sekarang : {stack}")

stack.append(6)
print(f"tumpukan masuk : {6}")
print(f"tumpukan sekarang : {stack}")

stack.append(7)
print(f"tumpukan masuk : {7}")
print(f"tumpukan sekarang : {stack}")

out = stack.pop()
print(f"tumpukan masuk : {out}")
print(f"tumpukan sekarang : {stack}")